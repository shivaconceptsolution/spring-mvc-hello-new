package scs.bao;





import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import scs.dao.Student;

@Controller
public class StudentController  {
	@RequestMapping("stuload")
	public ModelAndView siLoadFunction(ModelMap model)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Query q = ss.createQuery("from Student s");
		List lst = q.list();
		
		
		model.addAttribute("keylist",lst);
		return new ModelAndView("stuview","command",new Student());
	}
	
	@RequestMapping("stucode")
	public ModelAndView sicodeFunction(@ModelAttribute("spring-mvc-hello")Student s, ModelMap model)
	{
		//String info = s.getRno() + " "+ s.getSname();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		if(ss.get(Student.class,s.getRno())!=null)
		{
			model.addAttribute("key","Rno already exist");
		}
		else
		{
		ss.save(s);
		tx.commit();
		model.addAttribute("key","Data Saved Successfully");
		}
		Query q = ss.createQuery("from Student s");
		List lst = q.list();
		
		
		model.addAttribute("keylist",lst);
		return new ModelAndView("stuview","command",new Student());
	}
	@RequestMapping("stuedit")
	public ModelAndView siEditFunction(HttpServletRequest request,ModelMap model)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Student obj =(Student) ss.load(Student.class, Integer.parseInt(request.getParameter("q")));
		return new ModelAndView("stufindview","command",obj);
	}
	@RequestMapping("stuupdate")
	public ModelAndView stuupdateFunction(@ModelAttribute("spring-mvc-hello")Student s, ModelMap model)
	{
		//String info = s.getRno() + " "+ s.getSname();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.update(s);
		tx.commit();
		
		return new ModelAndView("redirect:stuload.do");
	}
	@RequestMapping("studelete")
	public ModelAndView siDeleteFunction(HttpServletRequest request,ModelMap model)
	{
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Student obj =(Student) ss.load(Student.class, Integer.parseInt(request.getParameter("q")));
		return new ModelAndView("studeleteview","command",obj);
	}
	@RequestMapping("studeleteCode")
	public ModelAndView studeleteCodeFunction(@ModelAttribute("spring-mvc-hello")Student s, ModelMap model)
	{
		//String info = s.getRno() + " "+ s.getSname();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.delete(s);
		tx.commit();
		
		return new ModelAndView("redirect:stuload.do");
	}
}
