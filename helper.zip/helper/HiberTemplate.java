package helper;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import scs.dao.Student;

public class HiberTemplate {
	static Configuration cfg ;
	static  SessionFactory sf;
	static  Session ss;
   public static void scsConfigure()
   {
	    cfg= new Configuration();
	    cfg.configure("hibernate.cfg.xml");
	    sf = cfg.buildSessionFactory();
	    ss = sf.openSession();
   }
   public static void scsInsertData(Object o)
   {
	   
	   Transaction tx = ss.beginTransaction();
	   ss.save(o);
	   tx.commit();
	 
   }
   public static Query scsGetData(String qu)
   {
	      ss = sf.openSession();
		  Query q = ss.createQuery(qu);
		  return q;
   }
   public static Object findData(Class c, int pk)
   {
	    ss = sf.openSession();
	    return ss.get(c,pk);
	  
   }
   public static void closeConn()
   {
	   ss.close();
   }
}
