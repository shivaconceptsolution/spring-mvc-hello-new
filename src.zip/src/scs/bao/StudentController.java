package scs.bao;





import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import scs.dao.Student;

@Controller
public class StudentController  {
	@RequestMapping("stuload")
	public ModelAndView siLoadFunction()
	{
		return new ModelAndView("stuview","command",new Student());
	}
	
	@RequestMapping("stucode")
	public ModelAndView sicodeFunction(@ModelAttribute("spring-mvc-hello")Student s, ModelMap model)
	{
		//String info = s.getRno() + " "+ s.getSname();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		ss.save(s);
		tx.commit();
		Query q = ss.createQuery("from Student s");
		List lst = q.list();
		
		model.addAttribute("key","Data Saved Successfully");
		model.addAttribute("keylist",lst);
		return new ModelAndView("stuview","command",new Student());
	}
}
